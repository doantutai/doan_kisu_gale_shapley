<div class="container">
	<div class="col-md-5 col-md-push-3">
		<div class="form-area">  
			<form role="form" action="" method="POST">
				<br style="clear:both">
				<h3 style="margin-bottom: 25px; text-align: center;">Nhập giáo viên hướng dẫn</h3>
				<div class="form-group">
					<input type="text" class="form-control" id="name" name="hotengiaovien" placeholder="Họ tên giáo viên..." required>
				</div>
				<div class="form-group">
					<input type="text" class="form-control" id="email" name="chitieu" placeholder="Chỉ tiêu..." required>
				</div>
				<div class="form-group">
					<select name="trinhdo" class="form-control">
						<option>Chọn trình độ</option>
						<option value='0'>Cao Học</option>
						<option value="1">Thạc sĩ</option>
						<option value="2">Tiến sĩ</option>
						<option value="3">Phó GS</option>
						<option value="4">Giáo sư</option>
					</select>
				</div>
				<div class="form-group">
					<select name="chuyenmon" class="form-control">
						<option>Chọn chuyên môn</option>
						<option value='0'>KHMT</option>
						<option value="1">CNTT</option>
					</select>
				</div>
				<div class="form-group">
					<select name="gioitinh" class="form-control">
						<option>Chọn giới tính</option>
						<option value='0'>Nam</option>
						<option value="1">Nữ</option>
					</select>
				</div>
				<div class="form-group">
					<input type="text" class="form-control" id="subject" name="dotuoi" placeholder="Độ tuổi..." required>
				</div>
				<div class="form-group">
					<span class="help-block"><p id="characterLeft" class="help-block ">Nhập các trường thông tin đầy đủ</p></span>                    
				</div>

				<input type="submit" id="submit" name="nhapgiaovien" class="btn btn-primary pull-right" value="Nhập giáo viên">
			</form>
		</div>
	</div>
</div>
<?php
if(isset($_POST['nhapgiaovien']))
{
	if($_POST['hotengiaovien'] == NULL){
		echo "Vui lòng nhập họ tên giáo viên <br />";
	}else{
		$hotengiaovien=$_POST['hotengiaovien'];
	}
	if($_POST['chitieu'] == NULL){
		echo "Vui lòng nhập chỉ tiêu giáo viên <br />";
	}else{
		$chitieu=$_POST['chitieu'];
	}
	$trinhdo=$_POST['trinhdo'];
	if($trinhdo=='0')
		$trinhdo1="Cao học";
	if($trinhdo=='1')
		$trinhdo1="Thạc sĩ";
	if($trinhdo=='2')
		$trinhdo1="Tiến sĩ";
	if($trinhdo=='3')
		$trinhdo1="Phó GS";
	if($trinhdo=='4')
		$trinhdo1="Giáo sư";
	$chuyenmon=$_POST['chuyenmon'];
	if($chuyenmon=='0')
		$chuyenmon1="KHMT";
	if($chuyenmon=='1')
		$chuyenmon1="CNTT";
	if($_POST['dotuoi'] == NULL){
		echo "Vui lòng nhập tuổi giáo viên <br />";
	}else{
		$dotuoi=$_POST['dotuoi'];
	}
	$gioitinh=$_POST['gioitinh'];
	if($gioitinh=='0')
		$gioitinh1="Nam";
	if($gioitinh=='1')
		$gioitinh1="Nữ";
	// if($hotengiaovien && $chitieu && $trinhdo && $chuyenmon && $dotuoi && $gioitinh){

		$sql2="insert into giaovien(hotengiaovien,chitieu,trinhdo,chuyenmon,dotuoi,gioitinh) values('$hotengiaovien','$chitieu','$trinhdo1','$chuyenmon1','$dotuoi','$gioitinh1')";
		mysql_query("SET NAMES 'UTF8'"); 
		 mysql_query($sql2);
	// 	header("location:?m=");
	// 	exit();
	// }
}
?>