
<div class="container">
	<div class="col-md-5 col-md-push-3">
		<div class="form-area">  
			<form role="form" action="" method="POST">
				<br style="clear:both">
				<h3 style="margin-bottom: 25px; text-align: center;">Nhập điều kiện của sinh viên</h3>
				<div class="form-group">
					<select name="idsinhvien" class="form-control">
						<?php
						$sql2="select * from sinhvien";
						mysql_query("SET NAMES 'UTF8'");
						$query=mysql_query($sql2);
						while($data=mysql_fetch_assoc($query)){
							?>
							<option value='<?php echo $data['idsinhvien']?>'><?php echo $data['idsinhvien']."-".$data['hotensinhvien']?></option>
							<?php
						}
						?>
					</select>
				</div>
				<div class="form-group">
					<select name="tendieukien" class="form-control">
						<option value='0'>Trình độ</option>
						<option value='1'>Chuyên môn</option>
						<option value='2'>Giới tính</option>
						<option value='3'>Độ tuổi</option>
					</select>
				</div>
				<div class="form-group">
					<select name="dieukien" class="form-control">
						<option value="0">=</option>
						<option value='1'>></option>
						<option value="2">>=</option>
						<option value="3"><</option>
						<option value="4"><=</option>
					</select>
				</div>
				<div class="form-group">
					<!-- <form method="GET" id="form_search"> -->
						<input type="text" class="form-control" id="giatridieukien1" name="giatridieukien" placeholder="Giá trị điều kiện..." required>
					<!-- </form> -->
				</div>
				<div class="form-group">
					<span class="help-block"><p id="characterLeft" class="help-block ">Nhập các trường thông tin đầy đủ</p></span>                    
				</div>

				<input type="submit" id="submit" name="themdkgiaovien" class="btn btn-primary pull-right" value="Thêm đk giáo viên">
			</form>
		</div>
	</div>
</div>
<?php
if(isset($_POST['themdkgiaovien']))
{
	
	$tendieukien=$_POST['tendieukien'];
	if($tendieukien=='0')
		$tendieukien1="Điểm toán";
	if($tendieukien=='1')
		$tendieukien1="Điểm văn";
	if($tendieukien=='2')
		$tendieukien1="Điểm anh";
	if($tendieukien=='3')
		$tendieukien1="Trung bình";
	if($tendieukien=='4')
		$tendieukien1="Hạnh kiểm";
	$idgiaovien=$_POST['idgiaovien'];
	$dieukien=$_POST['dieukien'];
	if($dieukien=='0')
		$dieukien1="=";
	if($dieukien=='1')
		$dieukien1=">";
	if($dieukien=='2')
		$dieukien1=">=";
	if($dieukien=='3')
		$dieukien1="<";
	if($dieukien=='4')
		$dieukien1="<=";
	$giatridieukien=$_POST['giatridieukien'];
	// if($tendieukien && $dieukien && $giatridieukien && $idgiaovien){

		$sql2="insert into dieukiengiaovien(idgiaovien,tendieukien,dieukien,giatridieukien) values('$idgiaovien','$tendieukien1','$dieukien1','$giatridieukien')";
		mysql_query("SET NAMES 'UTF8'");
		mysql_query($sql2);
		header("location:?m=");
		// exit();
	// }
}
?>