                    //<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#product_view"><i class="fa fa-search"></i> Quick View</button>
function myFunction(x) {
    $("#item_view").modal();
};

   