<div class="row"  style="margin-top:50px">
	<div class="col-md-4">
		<table class="table table-inbox table-hover">				
			<thead>
				<tr class="unread">
					<th class="view-message  dont-show">Mã giáo viên</th>
					<th class="view-message">Họ và tên</th>
					<th class="view-message" style="text-align: center;">Action</th>
				</tr>
			</thead>
			<tbody>
				<?php
				$sql="select * from giaovien";
				mysql_query("SET NAMES 'UTF8'");
				$query=mysql_query($sql);
				while($data=mysql_fetch_assoc($query))
				{
					?>
					<tr>
						<td class='view-message  dont-show'><h5>GV<?php echo $data['idgiaovien'];?></h5></td>
						<td onclick="myFunction(this)" class="view-message"><h5><?php echo $data['hotengiaovien'];?></h5></td> 
						<td>
							<span class="btn-group pull-right" style="margin-top: 5px">
								<button class="btn btn-warning btn-xs" data-toggle="modal" data-target= "#item_edit"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button>
								<button class="btn btn-danger btn-xs"; data-toggle="modal" data-target="#item_remove"><i class="fa fa-times" aria-hidden="true"></i></button>
							</span>
						</td>
					</tr>
					<?php
				}
				?>
			</tbody>
		</table>
		<table class="table table-inbox table-hover">				
			<thead>
				<tr class="unread">
					<th class="view-message  dont-show">Mã sinh viên</th>
					<th class="view-message">Họ và tên</th>
					<th class="view-message" style="text-align: center;">Action</th>
				</tr>
			</thead>
			<tbody>
				<?php
				$sql="select * from sinhvien";
				mysql_query("SET NAMES 'UTF8'");
				$query=mysql_query($sql);
				while($data=mysql_fetch_assoc($query))
				{
					?>
					<tr>
						<td class='view-message  dont-show'><h5>SV<?php echo $data['idsinhvien'];?></h5></td>
						<td onclick="myFunction(this)" class="view-message"><h5><?php echo $data['hotensinhvien'];?></h5></td> 
						<td>
							<span class="btn-group pull-right" style="margin-top: 5px">
								<button class="btn btn-warning btn-xs" data-toggle="modal" data-target= "#item_edit"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button>
								<button class="btn btn-danger btn-xs"; data-toggle="modal" data-target="#item_remove"><i class="fa fa-times" aria-hidden="true"></i></button>
							</span>
						</td>
					</tr>
					<?php
				}
				?>
			</tbody>
		</table>
	</div>
	<div class="col-md-8">
		<div class="mail-option">
			<table class="table table-inbox table-hover">				
				<thead>
					<tr class="unread">
						<th class="col-sm-3 view-message  dont-show">Id giáo viên</th>
						<th class="view-message col-sm-3">Tên điều kiện</th>
						<th class="view-message col-sm-3">Điều kiện</th>
						<th class="view-message col-sm-3">Giá trị điều kiện</th>
					</tr>
				</thead>
				<tbody>
					<?php
					$sql1="select * from dieukiengiaovien";
					mysql_query("SET NAMES 'UTF8'");
					$query1=mysql_query($sql1);
					while($data1=mysql_fetch_assoc($query1))
					{
						?>
						<tr>
							<td onclick="myFunction(this)" class="view-message  dont-show"><h5><?php echo $data1['idgiaovien'];?></h5></td>
							<td onclick="myFunction(this)" class="view-message"><h5><?php echo $data1['tendieukien'];?></h5></td> 
							<td onclick="myFunction(this)"><?php echo $data1['dieukien'];?></td> 
							<td onclick="myFunction(this)" class="view-message  text-left"><h5><?php echo $data1['giatridieukien'];?></h5></td> 
						</tr>
						<?php
					}
					?>
				</tbody>
			</table>
			<table class="table table-inbox table-hover">				
				<thead>
					<tr class="unread">
						<th class="col-sm-3 view-message  dont-show">Id sinh viên</th>
						<th class="view-message col-sm-3">Tên điều kiện</th>
						<th class="view-message col-sm-3">Điều kiện</th>
						<th class="view-message col-sm-3">Giá trị điều kiện</th>
					</tr>
				</thead>
				<tbody>
					<?php
					$sql1="select * from dieukiensinhvien";
					mysql_query("SET NAMES 'UTF8'");
					$query1=mysql_query($sql1);
					while($data1=mysql_fetch_assoc($query1))
					{
						?>
						<tr>
							<td onclick="myFunction(this)" class="view-message  dont-show"><h5><?php echo $data1['idsinhvien'];?></h5></td>
							<td onclick="myFunction(this)" class="view-message"><h5><?php echo $data1['tendieukien'];?></h5></td> 
							<td onclick="myFunction(this)"><?php echo $data1['dieukien'];?></td> 
							<td onclick="myFunction(this)" class="view-message  text-left"><h5><?php echo $data1['giatridieukien'];?></h5></td> 
						</tr>
						<?php
					}
					?>
				</tbody>
			</table>
		</div>

	</div>
	
</div>