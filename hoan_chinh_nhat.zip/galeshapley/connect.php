<?php
$conn=mysql_connect("localhost", "root", "") or die("can't connect database");
    mysql_select_db("galeshapley",$conn);
?>