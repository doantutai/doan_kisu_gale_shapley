<div class="container">

	<div class="row"  style="margin-top:50px">
	<h2 style='text-align: center;color:red'>KẾT QUẢ THUẬT TOÁN</h2>
		<div class="col-md-4">
			<table class="table table-inbox table-hover">				
				<thead>
					<tr class="unread">
						<th class="view-message  dont-show">Giáo viên</th>
						<th class="view-message">Sinh viên</th>
						<th class="view-message" style="text-align: center;">Action</th>
					</tr>
				</thead>
				<tbody>
					<?php
					$sql="select * from topyeuthich";
					mysql_query("SET NAMES 'UTF8'");
					$query=mysql_query($sql);
					while($data=mysql_fetch_assoc($query))
					{
						?>
						<tr>
							<td class='view-message  dont-show'><h5><?php echo $data['idgiaovien'];?></h5></td>
							<td onclick="myFunction(this)" class="view-message"><h5><?php echo $data['idsinhvien'];?></h5></td>
							<td>
								<span class="btn-group pull-right" style="margin-top: 5px">
									<button class="btn btn-warning btn-xs" data-toggle="modal" data-target= "#item_edit"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button>
									<button class="btn btn-danger btn-xs"; data-toggle="modal" data-target="#item_remove"><i class="fa fa-times" aria-hidden="true"></i></button>
								</span>
							</td>
						</tr>
						<?php
					}
					?>
				</tbody>

			</table>
		</div>
		<div class="col-md-8">
			<table>
				<tbody>
						<div class="row">
							<?php
							$sql1="select * from topyeuthich";
							mysql_query("SET NAMES 'UTF8'");
							$query1=mysql_query($sql1);
							while($data1=mysql_fetch_assoc($query1))
							{
								?>
								<?php
								echo "<div class='alert-group'>";
								echo "<div class='alert alert-info' style='color:blue;font-weight:500'>";
								if(strlen($data1['idsinhvien'])==0)
									echo "Giáo viên ". $data1['idgiaovien']." không hướng dẫn sinh viên nào";
								else
									if(strlen($data1['idsinhvien'])!=0)
										echo "Giáo viên ". $data1['idgiaovien'] ." hướng dẫn sinh viên ". $data1['idsinhvien']."";
									?>
									
									<?php
									echo "</div>";
									echo "</div>";
								}
								?>
						</div>
					</tbody>
				</table>
			</div>
		</div>
	</div>