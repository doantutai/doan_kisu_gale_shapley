<?php
require("connect.php");
?>
<div class="container">
	<div class="col-md-5 col-md-push-3">
		<div class="form-area">  
			<form role="form" action="" method="POST">
				<br style="clear:both">
				<h3 style="margin-bottom: 25px; text-align: center;">Nhập sinh viên thực tập</h3>
				<div class="form-group">
					<input type="text" class="form-control" id="name" name="hotensinhvien" placeholder="Họ tên sinh viên..." required>
				</div>
				<div class="form-group">
					<input type="text" class="form-control" id="email" name="diemtoan" placeholder="Điểm toán..." required>
				</div>
				<div class="form-group">
					<input type="text" class="form-control" id="email" name="diemvan" placeholder="Điểm văn..." required>
				</div>
				<div class="form-group">
					<input type="text" class="form-control" id="email" name="diemanh" placeholder="Điểm anh..." required>
				</div>
				<div class="form-group">
					<select name="hanhkiem" class="form-control">
						<option>Chọn hạnh kiểm</option>
						<option value='0'>Yếu</option>
						<option value="1">Trung bình</option>
						<option value="2">Khá</option>
						<option value="3">Tốt</option>
					</select>
				</div>
				<div class="form-group">
					<span class="help-block"><p id="characterLeft" class="help-block ">Nhập các trường thông tin đầy đủ</p></span>                    
				</div>

				<input type="submit" id="submit" name="nhapsinhvien" class="btn btn-primary pull-right" value="Nhập sinh viên">
			</form>
		</div>
	</div>
</div>
<?php
if(isset($_POST['nhapsinhvien']))
{
	if($_POST['hotensinhvien'] == NULL){
		echo "Vui lòng nhập họ tên sinh viên <br />";
	}else{
		$hotensinhvien=$_POST['hotensinhvien'];
	}
	if($_POST['diemtoan'] == NULL){
		echo "Vui lòng nhập điểm toán <br />";
	}else{
		$diemtoan=$_POST['diemtoan'];
	}
	if($_POST['diemvan'] == NULL){
		echo "Vui lòng nhập điểm văn <br />";
	}else{
		$diemvan=$_POST['diemvan'];
	}
	if($_POST['diemanh'] == NULL){
		echo "Vui lòng nhập điểm anh <br />";
	}else{
		$diemanh=$_POST['diemanh'];
	}
	$hanhkiem=$_POST['hanhkiem'];
	if($hanhkiem=='0')
		$hanhkiem1="Yếu";
	if($hanhkiem=='1')
		$hanhkiem1="Trung bình";
	if($hanhkiem=='2')
		$hanhkiem1="Khá";
	if($hanhkiem=='3')
		$hanhkiem1="Tốt";
	$diemtrungbinh=(float)($diemtoan+$diemvan+$diemanh)/3;
	if($hotensinhvien && $diemtoan && $diemvan && $diemanh && $hanhkiem){

		$sql5="insert into sinhvien values(NULL,'$hotensinhvien','$diemtoan','$diemvan','$diemanh','$diemtrungbinh','$hanhkiem1')";
		 mysql_query("SET NAMES 'UTF8'");
		 echo $sql5;
		 mysql_query($sql5);
		header("location:?m=");
		exit();
	}
}
?>