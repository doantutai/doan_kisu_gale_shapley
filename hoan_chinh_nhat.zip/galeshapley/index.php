<?php
require("connect.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Phân công giảng viên hướng dẫn sinh viên thực tập</title>
	<link href="font-awesome.min.css" rel="stylesheet"> 
	<script src='bootstrap.min.js' type="text/javascript"></script>
	<script src='jquery-1.11.0.min.js' type="text/javascript"></script>
	<link rel="stylesheet" href="style.css">
	<link rel="stylesheet" href="bootstrap.min.css">
	<link rel="stylesheet" href="jquery-ui.css">
	<script src="jquery-1.12.0.min.js"></script>
	<script src="jquery-ui.js"></script>
</head>
<script>
	function myFunction(x) {
		$("#item_view").modal();
	};
</script>
<script type="text/javascript">
	$(document).ready(function()
	{  
    //sử dụng autocomplete với input có id = key
    $( "input#giatridieukien" ).autocomplete({
        source:'autodkgiaovien.php', //link xử lý dữ liệu tìm kiếm
    })
});
	$(document).ready(function()
	{  
    //sử dụng autocomplete với input có id = key
    $( "input#giatridieukien1" ).autocomplete({
        source:'autodksinhvien.php', //link xử lý dữ liệu tìm kiếm
    })
});
</script>
<body>
	<div class="container">

		<div class="mail-box">
			<div class="inbox-head">
				<h3><a href="?m=" style="text-decoration: none;color:White">Thuật toán HR</a></h3>
				<form action="#" class="pull-right position">
					<div class="input-append">
						<input type="text" class="sr-input" placeholder="Tìm kiếm">
						<button class="btn sr-btn" type="button"><i class="fa fa-search"></i></button>
					</div>
				</form>
			</div>
			<button class="btn btn-default pull-right" style="margin-top:20px;" data-toggle="modal" data-target= "#item_add"><i class="glyphicon glyphicon-plus"></i><a href='?m=chaychuongtrinh'>Chạy chương trình</a></button>
			<button class="btn btn-default pull-right" style="margin-top:20px;" data-toggle="modal" data-target= "#item_add"><i class="glyphicon glyphicon-plus"></i><a href='?m=danhsachgv'>Hiển thị danh sách giáo viên</a></button>
			<button class="btn btn-default pull-right" style="margin-top:20px;" data-toggle="modal" data-target= "#item_add"><i class="glyphicon glyphicon-plus"></i><a href='?m=danhsachsv'>Hiển thị danh sách sinh viên</a></button>
			<button class="btn btn-default pull-right" style="margin-top:20px;" data-toggle="modal" data-target= "#item_add"><i class="glyphicon glyphicon-plus"></i><a href='?m=themgiaovien'>Thêm giáo viên</a></button>
			<button class="btn btn-default pull-right" style="margin-top:20px;" data-toggle="modal" data-target= "#item_add"><i class="glyphicon glyphicon-plus"></i><a href='?m=themsinhvien'>Thêm sinh viên</a></button>
			<button class="btn btn-default pull-right" style="margin-top:20px;" data-toggle="modal" data-target= "#item_add"><i class="glyphicon glyphicon-plus"></i><a href='?m=themdkgiaovien'>Thêm điều kiện giáo viên</a></button>
			<!-- <button class="btn btn-default pull-right" style="margin-top:20px;" data-toggle="modal" data-target= "#item_add"><i class="glyphicon glyphicon-plus"></i><a href='?m=themdksinhvien'>Thêm điều kiện sinh viên</a></button> -->
			<div style="margin-top:20px;"></div>
			<?php
			$mod=$_GET['m'];
			if($mod == '')$mod='trangchu';
			include("$mod.php");
			?>
		</div>
	</div>
</div>
</div>

</body>
</html>