package doan;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;

public class Student {
	ArrayList<Teacher> preferList = new ArrayList<Teacher>();
	ArrayList<Teacher> fianceList=new ArrayList<Teacher>();
	static ArrayList<Student>  x=new ArrayList<Student>();//cop chay
	String name;
	public String hotensinhvien;
	public float diemtoan;
	public float diemvan;
	public float diemanh;
	public float diemtrungbinh;
	public String hanhkiem;
	public int idsinhvien;
	public String tendieukien;
	public String dieukien;
	public String giatridieukien;
	public String themyeuthichgv;
	public String idsinhviendk;
	public String wheredksinhvien;
	Student(String name){
		this.name=name;
	}
	
	public ArrayList<Teacher> getFianceList() {
		return fianceList;
	}

	public void setFianceList(ArrayList<Teacher> fianceList) {
		this.fianceList = fianceList;
	}

	public ArrayList<Teacher> getPreferList() {
		return preferList;
	}

	public void setPreferList(ArrayList<Teacher> preferList) {
		this.preferList = preferList;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getHotensinhvien() {
		return hotensinhvien;
	}

	public void setHotensinhvien(String hotensinhvien) {
		this.hotensinhvien = hotensinhvien;
	}

	public float getDiemtoan() {
		return diemtoan;
	}

	public void setDiemtoan(float diemtoan) {
		this.diemtoan = diemtoan;
	}

	public float getDiemvan() {
		return diemvan;
	}

	public void setDiemvan(float diemvan) {
		this.diemvan = diemvan;
	}

	public float getDiemanh() {
		return diemanh;
	}

	public void setDiemanh(float diemanh) {
		this.diemanh = diemanh;
	}

	public float getDiemtrungbinh() {
		return diemtrungbinh;
	}

	public void setDiemtrungbinh(float diemtrungbinh) {
		this.diemtrungbinh = diemtrungbinh;
	}

	public String getHanhkiem() {
		return hanhkiem;
	}

	public void setHanhkiem(String hanhkiem) {
		this.hanhkiem = hanhkiem;
	}

	public int getIdsinhvien() {
		return idsinhvien;
	}

	public void setIdsinhvien(int idsinhvien) {
		this.idsinhvien = idsinhvien;
	}

	public String getTendieukien() {
		return tendieukien;
	}

	public void setTendieukien(String tendieukien) {
		this.tendieukien = tendieukien;
	}

	public String getDieukien() {
		return dieukien;
	}

	public void setDieukien(String dieukien) {
		this.dieukien = dieukien;
	}

	public String getGiatridieukien() {
		return giatridieukien;
	}

	public void setGiatridieukien(String giatridieukien) {
		this.giatridieukien = giatridieukien;
	}

	public String getThemyeuthichgv() {
		return themyeuthichgv;
	}

	public void setThemyeuthichgv(String themyeuthichgv) {
		this.themyeuthichgv = themyeuthichgv;
	}

	public String getIdsinhviendk() {
		return idsinhviendk;
	}

	public void setIdsinhviendk(String idsinhviendk) {
		this.idsinhviendk = idsinhviendk;
	}

	public String getWheredksinhvien() {
		return wheredksinhvien;
	}

	public void setWheredksinhvien(String wheredksinhvien) {
		this.wheredksinhvien = wheredksinhvien;
	}

	@Override
	public String toString() {
		diemtrungbinh=(float)(diemtoan+diemvan+diemanh)/3;
		return "" + hotensinhvien + "," + diemtoan + "," + diemvan
				+ "," + diemanh + "," + diemtrungbinh + "," + hanhkiem + "";
	}
	public String dieukien() {
		return "" + tendieukien + "" + dieukien + "'" + giatridieukien
				+ "'";
	}
	
	public String hienthidieukien() {
		return ""+themyeuthichgv +"";
	}
	public String hienthiidsinhviendk() {
		return ""+idsinhviendk +"";
	}
	public String wheredksinhvien() {
		return ""+wheredksinhvien +"";
	}
	public Student(String hotensinhvien, float diemtoan, float diemvan, float diemanh, float diemtrungbinh,
			String hanhkiem) {
		super();
		this.hotensinhvien = hotensinhvien;
		this.diemtoan = diemtoan;
		this.diemvan = diemvan;
		this.diemanh = diemanh;
		this.diemtrungbinh = diemtrungbinh;
		this.hanhkiem = hanhkiem;
	}
	public String hienthiyeuthich() {
		return "" + idsinhvien + "," + tendieukien + "," + dieukien
				+ "," + giatridieukien  + "";
	}
	public Student() {
		
	}
	public void readData()
	{
		Scanner input=new Scanner(System.in);
			System.out.println("Nhập họ tên sinh viên:");
			hotensinhvien=input.nextLine();
			System.out.println("Nhập điểm toán:");
			diemtoan=Float.parseFloat(input.nextLine());
			System.out.println("Nhập điểm văn:");
			diemvan=Float.parseFloat(input.nextLine());
			System.out.println("Nhập điểm anh:");
			diemanh=Float.parseFloat(input.nextLine());
			System.out.println("Nhập hạnh kiểm:");
			hanhkiem=input.nextLine();
	}
	public void nhapdieukiensinhvien()
	{
		Scanner input=new Scanner(System.in);
		System.out.println("Nhập id sinh viên:");
		idsinhvien=Integer.parseInt(input.nextLine());
		System.out.println("Nhập tên điều kiện:");
		tendieukien=input.nextLine();
		System.out.println("Nhập điều kiện:");
		dieukien=input.nextLine();
		System.out.println("Nhập giá trị điều kiện:");
		giatridieukien=input.nextLine();
	}
	public boolean propose()
	{
	for(int i=0;i<this.preferList.size();i++)
	{
			if(engaged(this.preferList.get(i)))
			{
				this.preferList.remove(i);	
				return true;
			}
			else
			{
				this.preferList.remove(i); 
				i=i-1;
			}
	}
	return false;
	}
	public boolean engaged(Teacher x)
    {
    System.out.println();
    return x.addMenInList(this);
	}
}
