package doan;
import java.util.*;
public class Nhapgiaovien {
	ArrayList nhap=new ArrayList<>();
	public String hotengiaovien;
	public int chitieu;
	public String trinhdo;
	public String chuyenmon;
	public String gioitinh;
	public int dotuoi;
	public ArrayList getNhap() {
		return nhap;
	}
	public void setNhap(ArrayList nhap) {
		this.nhap = nhap;
	}
	public String getHotengiaovien() {
		return hotengiaovien;
	}
	public void setHotengiaovien(String hotengiaovien) {
		this.hotengiaovien = hotengiaovien;
	}
	public int getChitieu() {
		return chitieu;
	}
	public void setChitieu(int chitieu) {
		this.chitieu = chitieu;
	}
	public String getTrinhdo() {
		return trinhdo;
	}
	public void setTrinhdo(String trinhdo) {
		this.trinhdo = trinhdo;
	}
	public String getChuyenmon() {
		return chuyenmon;
	}
	public void setChuyenmon(String chuyenmon) {
		this.chuyenmon = chuyenmon;
	}
	public String getGioitinh() {
		return gioitinh;
	}
	public void setGioitinh(String gioitinh) {
		this.gioitinh = gioitinh;
	}
	public int getDotuoi() {
		return dotuoi;
	}
	public void setDotuoi(int dotuoi) {
		this.dotuoi = dotuoi;
	}
	public Nhapgiaovien(String hotengiaovien, int chitieu, String trinhdo, String chuyenmon, String gioitinh,
			int dotuoi) {
		super();
		this.hotengiaovien = hotengiaovien;
		this.chitieu = chitieu;
		this.trinhdo = trinhdo;
		this.chuyenmon = chuyenmon;
		this.gioitinh = gioitinh;
		this.dotuoi = dotuoi;
	}
	public Nhapgiaovien() {
		
	}
	
}
