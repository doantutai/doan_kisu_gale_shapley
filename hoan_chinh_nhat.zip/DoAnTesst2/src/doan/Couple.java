package doan;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.ArrayList;

public class Couple {
	ArrayList<Student> men = new ArrayList<>();
	Teacher teacher;
	public  Couple(Teacher teacher1,ArrayList<Student> student1) {
		this.men=student1;
		this.teacher=teacher1;
	}
	public String toString() 
	{
	    String mList= "";
	    mList = mList + teacher.getName()+" hướng dẫn ";
	    for(int i=0;i<men.size();i++)
	    mList = mList + men.get(i).getName()+",";
	   
	    return "{" + mList + '}';
	}
	public void themvaotop()
	{
		try {
			Class.forName("org.postgresql.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println("Loi 1");
		}

		String url = "jdbc:postgresql://localhost:5432/test";
		String mList= "";
		String mList1= "";
		try {
			String[] Split;
			Connection connection = DriverManager.getConnection(url, "postgres", "1234");
			for (int i = 0; i < men.size(); i++)
				mList = mList + men.get(i).getName()+",";
			    mList1 = teacher.getName();
				String sql = "INSERT INTO topyeuthich(idgiaovien,idsinhvien) VALUES(" + mList1 + ", '" + mList+"')";
				// System.out.println(sql);
				Statement st = connection.createStatement();
				st.executeUpdate(sql);

			connection.close();

		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("lôi thêm giáo viên 1  :"+e);
		}
	}
    public void display()
    {
    System.out.println(this.toString());
    } 
}
