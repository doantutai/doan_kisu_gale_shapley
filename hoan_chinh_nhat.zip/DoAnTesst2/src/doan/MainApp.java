package doan;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Scanner;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
public class MainApp {

    static ArrayList<Student> x =new ArrayList<Student>();
    static ArrayList<Teacher> y =new ArrayList<Teacher>();
    static ArrayList<Teacher> chitieu =new ArrayList<>();
    static ArrayList<dieukiensinhvien> dk =new ArrayList<>();
    static ArrayList<Student> dkInsert =new ArrayList<>();
    static dieukiensinhvien dk1=new dieukiensinhvien();
    static dieukiengiaovien dk2=new dieukiengiaovien();
    private static int maxNum;
    public static Scanner scann = new Scanner(System.in);
	public static void main(String[] args) {
		String choose = null;
		boolean exit = false;
		
		// TODO Auto-generated method stub
		//readfile("dulieu1.txt");
		showMenu();
		while (true) {
            choose = scann.nextLine();
            switch (choose) {
            case "1":
            	insertsinhvien();
                break;
            case "2":
            	insertgiaovien();
                break;
            case "3":
            	dk1.dieukiensinhvien();
                break;
            case "4":
            	dk2.dieukiengiaovien();
                break;
            case "5":
            	hienthisinhvien();
                break;
            case "6":
            	hienthigiaovien();
                break;
            case "7":
            	dk2.themdanhsachthieu();
                break;
            case "8":
            	dk1.themdanhsachthieu();
                break;
            case "9":
            	readfile();
        		laydanhsach();
        		laydanhsach1();
        		ArrayList<Couple> cp = doMarried();
        		for(int i=0;i<cp.size();i++) {
        			cp.get(i).display();
        			//cp.get(i).themvaotop();
        		}
                break;
            case "0":
                System.out.println("exited!");
                exit = true;
                break;
            default:
                System.out.println("invalid! please choose action in below menu:");
                break;
            }
            if (exit) {
                break;
            }
            // show menu
            showMenu();
        }

		//dk1.dieukiensinhvien();
		//nhapdieukiengiaovien();
		
	}
	public static void showMenu() {
        System.out.println("-----------menu------------");
        System.out.println("1. Thêm Student.");
        System.out.println("2. Thêm Teacher.");
        System.out.println("3. Chạy điều kiện Student.");
        System.out.println("4. Chạy điều kiện Teacher.");
        System.out.println("5. Hiển thị danh sách Student.");
        System.out.println("6. Hiển thị danh sách Teacher.");
        System.out.println("7. Thêm danh sách thiếu điều kiện Teacher.");
        System.out.println("8. Thêm danh sách thiếu điều kiện Student.");
        System.out.println("9. Chạy bài toán.");
        System.out.println("0. exit.");
        System.out.println("---------------------------");
        System.out.print("Please choose: ");
    }

	public static boolean check()
	{
	// dừng khi danh sách không còn ai
	    if(x.size()==0) return true;
	    else
	    {
	        int dem = 0;
	        for(int i=0;i<x.size();i++)
	            if(x.get(i).getPreferList().size() !=0)
	                  dem = dem+1;
		        else
		        {
		        x.remove(i);
		        i = i-1;
		        }
	        if(x.size()==0) return true;
	        if(dem==0)
	        return true;
	    }
	    return false;
	}
	public static ArrayList<Couple> doMarried()
	{
	     //Danh  sách đang phân công thực tập
	    ArrayList<Couple> cm = new ArrayList();
	         //kiểm tra xem có nên tiếp tục gửi lời đề nghị hay không
	    while(!check())
	    {
	        for(int i=0;i<x.size();i++)
	        {
	                 //nếu được giáo viên đồng ý thì phải loại bỏ khỏi danh sách
		        if(x.get(i).propose())
		        {
		        	x.remove(i);
		        	i--;
		        }
		        	//x.get(i).propose();
	        }
	        int h=0;
	        while(yeuthich.menList.size()>0)
	        {
	        	yeuthich.menList.get(h).propose();
	        	yeuthich.menList.remove(h);
	        }
	        //yeuthich.menList.get(0).propose(); lam ban dau
	         }
	    
	    // lưu lại trong Couple
	    for(int i=0;i< y.size();i++)
	    {              
	    Couple l = new Couple(y.get(i),y.get(i).getFianceList());
	    cm.add(l);
	    }              
	     return cm;
	 } 
	public static void insertgiaovien() {
		try {
			Class.forName("org.postgresql.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println("Loi 1");
		}

		String url = "jdbc:postgresql://localhost:5432/test";

		try {
			nhapgiaovien();
			String[] Split;
			Connection connection = DriverManager.getConnection(url, "postgres", "1234");
			for (int i = 0; i < y.size(); i++) {
				String line = y.get(i).toString();
				Split = line.split(",");
				String sql = "INSERT INTO giaovien(hotengiaovien,chitieu,trinhdo,chuyenmon,gioitinh,dotuoi) VALUES('" + Split[0].trim() + "', " + Split[1].trim() + ",'"+Split[2].trim()+"','"+Split[3].trim()+"','"+Split[4].trim()+"',"+Split[5].trim()+")";
				// System.out.println(sql);
				Statement st = connection.createStatement();
				st.executeUpdate(sql);

			}
			connection.close();

		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("lôi thêm giáo viên 1  :"+e);
		}

	}
	public static void insertsinhvien() {
		try {
			Class.forName("org.postgresql.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println("Loi 1");
		}

		String url = "jdbc:postgresql://localhost:5432/test";

		try {
			nhapsinhvien();
			String[] Split;
			Connection connection = DriverManager.getConnection(url, "postgres", "1234");
			for (int i = 0; i < x.size(); i++) {
				String line = x.get(i).toString();
				Split = line.split(",");
				String sql1 = "INSERT INTO sinhvien(hotensinhvien,diemtoan,diemvan,diemanh,diemtrungbinh,hanhkiem) VALUES('" + Split[0].trim() + "', " + Split[1].trim() + ","+Split[2].trim()+","+Split[3].trim()+","+Split[4].trim()+",'"+Split[5].trim()+"')";
				// System.out.println(sql);
				Statement st1 = connection.createStatement();
				st1.executeUpdate(sql1);

			}
			connection.close();

		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("lôi thêm sinh viên 1  :"+e);
		}

	}
	public static void nhapdieukiensinhvien() {
		try {
			Class.forName("org.postgresql.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println("Loi 1");
		}

		String url = "jdbc:postgresql://localhost:5432/test";

		try {
			dieukiensinhvien();
			String[] Split;
			Connection connection = DriverManager.getConnection(url, "postgres", "1234");
			for (int i = 0; i < x.size(); i++) {
				String line = x.get(i).hienthidieukien();
				Split = line.split(",");
				String sql1 = "INSERT INTO dieukiensinhvien(idsinhvien,tendieukien,dieukien,giatridieukien) VALUES(" + Split[0].trim() + ", '" + Split[1].trim() + "','"+Split[2].trim()+"','"+Split[3].trim()+"')";
				// System.out.println(sql);
				Statement st1 = connection.createStatement();
				st1.executeUpdate(sql1);

			}
			connection.close();
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("lôi thêm điều kiện sinh viên :"+e);
		}

	}
	public static void nhapgiaovien()
	{
		Scanner input=new Scanner(System.in);
		System.out.println("Moi nhap thông tin các giáo viên  :");
		maxNum=input.nextInt();
		for(int i=0;i<maxNum;i++)
		{
		Teacher b=new Teacher();
		b.readData();
		y.add(b);
		}
	}
	public static void nhapsinhvien()
	{
		Scanner input1=new Scanner(System.in);
		System.out.println("Moi nhap thông tin các sinh viên  :");
		maxNum=input1.nextInt();
		for(int i=0;i<maxNum;i++)
		{
		Student c=new Student();
		c.readData();
		x.add(c);
		}
	}
	public static void dieukiensinhvien()
	{
		Scanner input=new Scanner(System.in);
		System.out.println("Moi nhập số điều kiện sinh viên  :");
		maxNum=input.nextInt();
		for(int i=0;i<maxNum;i++)
		{
		Student dksv=new Student();
		dksv.nhapdieukiensinhvien();
		x.add(dksv);
		}
	}
	public static void dieukiengiaovien()
	{
		Scanner input=new Scanner(System.in);
		System.out.println("Moi nhập số điều kiện giáo viên  :");
		maxNum=input.nextInt();
		for(int i=0;i<maxNum;i++)
		{
		Teacher dksv=new Teacher();
		dksv.nhapdieukiengiaovien();
		y.add(dksv);
		}
	}
	public static void nhapdieukiengiaovien() {
		try {
			Class.forName("org.postgresql.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println("Loi 1");
		}
		String url = "jdbc:postgresql://localhost:5432/test";
		try {
			dieukiengiaovien();
			String[] Split;
			Connection connection = DriverManager.getConnection(url, "postgres", "1234");
			for (int i = 0; i < y.size(); i++) {
				String line = y.get(i).hienthigv();
				Split = line.split(",");
				String sql1 = "INSERT INTO dieukiengiaovien(idgiaovien,tendieukien,dieukien,giatridieukien) VALUES(" + Split[0].trim() + ", '" + Split[1].trim() + "','"+Split[2].trim()+"','"+Split[3].trim()+"')";
				// System.out.println(sql);
				Statement st1 = connection.createStatement();
				st1.executeUpdate(sql1);
			}
			connection.close();
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("lôi thêm điều kiện giáo viên :"+e);
		}

	}
	public static void hienthigiaovien() {
		try {
			Class.forName("org.postgresql.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println("Loi 1");
		}

		String url1 = "jdbc:postgresql://localhost:5432/test";
		try {
			Connection connection = DriverManager.getConnection(url1, "postgres", "1234");

			String sql = "SELECT * FROM giaovien";
			Statement st = connection.createStatement();
			ResultSet result = st.executeQuery(sql);

			while (result.next()) {
                                    
				Teacher b = new Teacher();


				b.setHotengiaovien(result.getString(2));
				b.setChitieu(result.getShort(3));
				y.add(b);
			}

			for (int i = 0; i < y.size(); i++) {

				System.out.println(y.get(i).toString());

			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("loi " + e);
		}
	}
	public static void hienthisinhvien() {
		try {
			Class.forName("org.postgresql.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println("Loi 1");
		}

		String url1 = "jdbc:postgresql://localhost:5432/test";
		try {
			Connection connection = DriverManager.getConnection(url1, "postgres", "1234");

			String sql = "SELECT * FROM sinhvien";
			Statement st = connection.createStatement();
			ResultSet result = st.executeQuery(sql);

			while (result.next()) {
                                    
				Student b = new Student();


				b.setHotensinhvien(result.getString(2));
				b.setDiemtoan(result.getFloat(3));
				b.setDiemvan(result.getFloat(4));
				b.setDiemanh(result.getFloat(5));
				b.setDiemtrungbinh(result.getFloat(6));
				b.setHanhkiem(result.getString(7));
				x.add(b);
			}

			for (int i = 0; i < x.size(); i++) {

				System.out.println(x.get(i).toString());

			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("loi hien thi sinh vien " + e);
		}
	}
	public static void laydanhsach1()
	{
		try {
			Class.forName("org.postgresql.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println("Loi 1");
		}
	    String url1 = "jdbc:postgresql://localhost:5432/test";
	    try 
	    {
	    	
	    	Connection connection = DriverManager.getConnection(url1, "postgres", "1234");
	    	String yt1 = "SELECT idsinhvien FROM yeuthichsinhvien order by idgiaovien asc";
			Statement ytsv = connection.createStatement();
			ResultSet ytsv1 = ytsv.executeQuery(yt1);
			int k1=0;
			int b1=0;
			String[] Split2;
			String Split3;
			int y2;
			System.out.println("\n\r");
			System.out.println("Danh sách sinh viên yêu thích sinh viên:");
			System.out.println("\n\r");
			while(ytsv1.next())
			{
				Split3=ytsv1.getString(1);
				Split3=Split3.trim();
				Split2=Split3.split(",");
				//System.out.println(Split2.length);
				System.out.println("\n\r");
				System.out.print(y.get(k1).getName()+" | ");
				for(y2=0;y2<Split2.length;y2++) {
					
					System.out.print(" "+x.get(Integer.parseInt(Split2[y2])-1).getName());
					y.get(b1).getPreferList().add(x.get(Integer.parseInt(Split2[y2])-1));
					//System.out.println("hehe");
				}
				b1++;
				k1++;
			}
		connection.close();    
		    
	    } catch (Exception e) {
			// TODO: handle exception
			System.out.println("lỗi thêm danh sách yêu thích sinh viên:"+e);
		}
	}
	public static void laydanhsach()
	{
		
		try {
			Class.forName("org.postgresql.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println("Loi 1");
		}
	    String url1 = "jdbc:postgresql://localhost:5432/test";
	    try 
	    {
	    	
	    	Connection connection = DriverManager.getConnection(url1, "postgres", "1234");
	    	String Split;
			
			int h;
			int b=0;
			int y1;
			int k=0;
			String yt = "SELECT idgiaovien FROM yeuthichgiaovien order by idsinhvien";
			Statement ytgv = connection.createStatement();
			ResultSet ytgv1 = ytgv.executeQuery(yt);
			System.out.println("\n\r");
			System.out.println("Danh sách sinh viên yêu thích giáo viên:");
			System.out.println("\n\r");
			while(ytgv1.next())
			{
				Split=ytgv1.getString(1);
				Split=Split.trim();
				String[] Split1=Split.split(",");
				h=0;
				//System.out.println(Split1.length);
				System.out.println("\n\r");
				System.out.print(x.get(k).getName()+" | ");
				for(y1=0;y1<Split1.length;y1++) {
					
					System.out.print(" "+y.get(Integer.parseInt(Split1[y1])-1).getName());
					x.get(b).getPreferList().add(y.get(Integer.parseInt(Split1[y1])-1));
					
				}
				b++;
				k++;
			}
			ytgv1.close();
		connection.close();    
		    
	    } catch (Exception e) {
			// TODO: handle exception
			System.out.println("lỗi thêm danh sách yêu thích giáo viên:"+e);
		}
	}
	public static void readfile() {
		
		int q = 0;
	    int dem =0;
	    int giaov,sinhv;
	    int friendgv=0;
	    String[] Split;
	    try {
			Class.forName("org.postgresql.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println("Loi 1");
		}
	    String url1 = "jdbc:postgresql://localhost:5432/test";
	    try 
	    {
	    	
	    	Connection connection1 = DriverManager.getConnection(url1, "postgres", "1234");
	    	
			String sql3 = "SELECT * FROM giaovien order by idgiaovien asc";
			Statement st3 = connection1.createStatement();
			ResultSet result3 = st3.executeQuery(sql3);
			while(result3.next())
			{
				giaov=result3.getInt(3);
				//Teacher teach=new Teacher();
				//teach.setName(Integer.toString(result3.getInt(3)));
				y.add(new Teacher("gv"+Integer.toString(giaov)));
			}
			result3.close();
			Statement st33 = connection1.createStatement();
			ResultSet result33 = st33.executeQuery(sql3);
			while(result33.next())
			{
				Teacher teach1=new Teacher();
				//teach1.setQ(result33.getInt(2));
				Teacher.setQ(result33.getInt(2));
				//chitieu.add(teach1);
			}
			result33.close();
			String sql4 = "SELECT * FROM sinhvien order by idsinhvien asc";
			Statement st4 = connection1.createStatement();
			ResultSet result4 = st4.executeQuery(sql4);
			while(result4.next())
			{
				sinhv=result4.getInt(1);
				//Student studen=new Student();
				//studen.setIdsinhvien(result4.getInt(1));
				x.add(new Student("sv"+Integer.toString(sinhv)));
			}
			//System.out.println(y.get(2).getName());
			result4.close();
		connection1.close();    
		    
	    } catch (Exception e) {
			// TODO: handle exception
			System.out.println("lỗi thêm import sinh viên vào x :"+e);
		}
	}
}
