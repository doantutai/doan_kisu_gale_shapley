package doan;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;


public class dieukiensinhvien {
	static ArrayList<Student> x =new ArrayList<>();
    static ArrayList<Teacher> y =new ArrayList<>();
    static ArrayList<MainApp> main =new ArrayList<>();
    static ArrayList<Student> dieukien =new ArrayList<>();
    static ArrayList<Student> dieukien1 =new ArrayList<>();
    static ArrayList<Student> idsinhviendk =new ArrayList<>();
    static ArrayList<Student> wheredksinhvien =new ArrayList<>();
    static ArrayList<String> themdanhsachthieusv =new ArrayList<>();
    public static boolean  CheckExist(String[] arr, String Numb)
    {
    	for  (int i = 0; i  < arr.length; i++)
    	{
    		if  (arr[i].equals(Numb))
    		{
    			return true;
    		}
    	}
    	return false;
    }
    public static void themdanhsachthieu()
    {
    	try {
			Class.forName("org.postgresql.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println("Loi 1");
		}

		String url = "jdbc:postgresql://localhost:5432/test";
		
		try {
			//nhapgiaovien();
			String[] Split;
			Connection connection3 = DriverManager.getConnection(url, "postgres", "1234");
//				String line = y.get(i).toString();
//				Split = line.split(",");
				String sql = "SELECT * from yeuthichgiaovien";
				// System.out.println(sql);
				Statement st = connection3.createStatement();
				ResultSet capnhatgv = st.executeQuery(sql);
				
				
				while(capnhatgv.next())
				{
					int i=0;
					String themds="";
					String line=capnhatgv.getString(1);
					Split=line.split(",");
					
					String sql5="SELECT idgiaovien from giaovien";
					Statement stt = connection3.createStatement();
					ResultSet capnhatgv1 = stt.executeQuery(sql5);
					
					while(capnhatgv1.next())
					{
						if  (CheckExist(Split, capnhatgv1.getString(1))==false)
						{
							themds  += capnhatgv1.getString(1)+",";
						}
						
					} 
					String sql6 = "UPDATE yeuthichgiaovien set idgiaovien='"+line+themds+",' where idsinhvien='"+capnhatgv.getString(2)+"'";
					System.out.println("insert:"+sql6);
					Statement st3 = connection3.createStatement();
					st3.executeUpdate(sql6);
					themdanhsachthieusv.clear();
				}
			connection3.close();

		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("lôi thêm danh sách giáo viên thiếu :"+e);
		}
    }
	public static void dieukiensinhvien() {
		try {
			Class.forName("org.postgresql.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println("Loi 1");
		}

		String url = "jdbc:postgresql://localhost:5432/test";

		try {
			String[] Split;
			int k=0,count=0;
			Connection connection = DriverManager.getConnection(url, "postgres", "1234");
			String idsv = "Select * from sinhvien order by idsinhvien asc";
			Statement idsv1 = connection.createStatement();
			ResultSet tim = idsv1.executeQuery(idsv);
			while(tim.next())
			{
				Student id=new Student();
				id.setIdsinhviendk(tim.getString(1));
				idsinhviendk.add(id);
			}
			tim.close();
			String sq = "Select count(*) from sinhvien";
			Statement dem = connection.createStatement();
			ResultSet chay = dem.executeQuery(sq);
			while(chay.next())
			{
				k++;
				count=chay.getInt(1);
			}
			chay.close();
			String sql1 = "Select * from dieukiensinhvien order by idsinhvien asc";
			 System.out.println(count);
			Statement st1 = connection.createStatement();
			Statement st11 = connection.createStatement();
			ResultSet rs = st1.executeQuery(sql1);
			
			int m=1;
			
			while (rs.next()) {
                
				Student b = new Student();
				b.setTendieukien(rs.getString(2));
				b.setDieukien(rs.getString(3));
				b.setGiatridieukien(rs.getString(4));
				dieukien.add(b);
			}
			rs.close();
			int h=0;
			Student st=new Student();
			int y=0;
			
			for(int u=0;u<count;u++)
			{
				
				String phepand="";
				ResultSet rss = st11.executeQuery(sql1);
				while(rss.next())
				{
					if(rss.getString(1).equals(idsinhviendk.get(u).hienthiidsinhviendk()))
					{
						phepand+=dieukien.get(y).dieukien()+" and ";
						
						y++;
					}
				}
				st.setWheredksinhvien(phepand+ " 1!=0 ");
				wheredksinhvien.add(st);
				System.out.println(wheredksinhvien.get(u).wheredksinhvien());
				//rss.close();
				String sql2 = "Select * from giaovien WHERE "+wheredksinhvien.get(u).wheredksinhvien()+" order by idgiaovien asc";
				System.out.println("e="+u);
				System.out.println(sql2);
				Statement st22 = connection.createStatement();
				ResultSet rs11 = st22.executeQuery(sql2);
				Statement st2 = connection.createStatement();
				ResultSet rs1 = st2.executeQuery(sql2);
				int l=0;
				int a=0;
				int count1=0;
				while(rs11.next()) {
					count1=rs11.getInt(3);
				}
				rs11.close();
				String danhsach="";
				while(rs1.next()) {
					
					Student c=new Student();
					c.setThemyeuthichgv(rs1.getString(3));
					dieukien1.add(c);
					a++;
					
					danhsach+=dieukien1.get(l).hienthidieukien()+",";
					System.out.println("danh sách giao vien từng người:"+dieukien1.get(l).hienthidieukien());
					l++;
					System.out.println(a);
				}
				if(danhsach.length()>0)
				{
					String sql3 = "INSERT INTO yeuthichgiaovien(idgiaovien,idsinhvien) values('"+danhsach+"','"+idsinhviendk.get(u).hienthiidsinhviendk()+"')";
					System.out.println("insert:"+sql3);
					Statement st3 = connection.createStatement();
					st3.executeUpdate(sql3);
					dieukien1.clear();
					st3.close();
				}
				danhsach="";
				rs1.close();
				st2.close();
			}
			
			
			connection.close();

		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("lỗi thêm yêu thích giáo viên 1 :"+e);
		}

	}
}
