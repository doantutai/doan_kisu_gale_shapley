package doan;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;


public class Teacher {
	ArrayList<Student> preferList=new ArrayList<>();
	ArrayList<Student> fianceList=new ArrayList<Student>();
	
	String name;
	static int q;
	Teacher(String name){
		this.name=name;
	}
	public String hotengiaovien;
	public int chitieu;
	public String trinhdo;
	public String chuyenmon;
	public String gioitinh;
	public int dotuoi;
	public int idgiaovien;
	public String tendieukien;
	public String dieukien;
	public String giatridieukien;
	public String themyeuthichsv;
	public String idgiaoviendk;
	public String wheredkgiaovien;
	public String themdanhsach;
	public  Teacher()
	{
		this.hotengiaovien="";
		this.chitieu=0;
	}
	public ArrayList<Student> getPreferList() {
		return preferList;
	}

	public void setPreferList(ArrayList<Student> preferList) {
		this.preferList = preferList;
	}

	public ArrayList<Student> getFianceList() {
		return fianceList;
	}
	public void setFianceList(ArrayList<Student> fianceList) {
		this.fianceList = fianceList;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public static int getQ() {
		return q;
	}
	public static void setQ(int q) {
		Teacher.q = q;
	}
	
	
	public String getTrinhdo() {
		return trinhdo;
	}
	public void setTrinhdo(String trinhdo) {
		this.trinhdo = trinhdo;
	}
	public String getChuyenmon() {
		return chuyenmon;
	}
	public void setChuyenmon(String chuyenmon) {
		this.chuyenmon = chuyenmon;
	}
	public String getGioitinh() {
		return gioitinh;
	}
	public void setGioitinh(String gioitinh) {
		this.gioitinh = gioitinh;
	}
	public int getDotuoi() {
		return dotuoi;
	}
	public void setDotuoi(int dotuoi) {
		this.dotuoi = dotuoi;
	}
	public String getHotengiaovien() {
		return hotengiaovien;
	}
	public void setHotengiaovien(String hotengiaovien) {
		this.hotengiaovien = hotengiaovien;
	}
	public int getChitieu() {
		return chitieu;
	}
	public void setChitieu(int chitieu) {
		this.chitieu = chitieu;
	}
	public int getIdgiaovien() {
		return idgiaovien;
	}
	public void setIdgiaovien(int idgiaovien) {
		this.idgiaovien = idgiaovien;
	}
	public String getTendieukien() {
		return tendieukien;
	}
	public void setTendieukien(String tendieukien) {
		this.tendieukien = tendieukien;
	}
	public String getDieukien() {
		return dieukien;
	}
	public void setDieukien(String dieukien) {
		this.dieukien = dieukien;
	}
	public String getGiatridieukien() {
		return giatridieukien;
	}
	public void setGiatridieukien(String giatridieukien) {
		this.giatridieukien = giatridieukien;
	}
	public String getThemyeuthichsv() {
		return themyeuthichsv;
	}
	public void setThemyeuthichsv(String themyeuthichsv) {
		this.themyeuthichsv = themyeuthichsv;
	}
	public String getIdgiaoviendk() {
		return idgiaoviendk;
	}
	public void setIdgiaoviendk(String idgiaoviendk) {
		this.idgiaoviendk = idgiaoviendk;
	}
	public String getWheredkgiaovien() {
		return wheredkgiaovien;
	}
	public void setWheredkgiaovien(String wheredkgiaovien) {
		this.wheredkgiaovien = wheredkgiaovien;
	}
	
	public String getThemdanhsach() {
		return themdanhsach;
	}
	public void setThemdanhsach(String themdanhsach) {
		this.themdanhsach = themdanhsach;
	}
	public String dieukien() {
		return "" + tendieukien + "" + dieukien + "'" + giatridieukien
				+ "'";
	}
	public String hienthidieukien() {
		return ""+themyeuthichsv +"";
	}
	public String hienthiidgiaoviendk() {
		return ""+idgiaoviendk +"";
	}
	public String wheredkgiaovien() {
		return ""+wheredkgiaovien +"";
	}
	public Teacher(String hotengiaovien, int chitieu, String trinhdo, String chuyenmon, String gioitinh, int dotuoi) {
		super();
		this.hotengiaovien = hotengiaovien;
		this.chitieu = chitieu;
		this.trinhdo = trinhdo;
		this.chuyenmon = chuyenmon;
		this.gioitinh = gioitinh;
		this.dotuoi = dotuoi;
	}
	public String hienthiyeuthich() {
		return "" + idgiaovien + "," + tendieukien + "," + dieukien
				+ "," + giatridieukien  + "";
	}
	@Override
	public String toString() {
		return "" + hotengiaovien + "," + chitieu + "," + trinhdo
				+ ", " + chuyenmon + "," + gioitinh + "," + dotuoi + "";
	}
	public String hienthigv() {
		return "" + idgiaovien + "," + tendieukien + "," + dieukien
				+ ", " + giatridieukien + "";
	}
	public void nhapdieukiengiaovien()
	{
		Scanner input=new Scanner(System.in);
		System.out.println("Nhập id giáo viên:");
		idgiaovien=Integer.parseInt(input.nextLine());
		System.out.println("Nhập tên điều kiện:");
		tendieukien=input.nextLine();
		System.out.println("Nhập điều kiện:");
		dieukien=input.nextLine();
		System.out.println("Nhập giá trị điều kiện:");
		giatridieukien=input.nextLine();
	}
	public void readData()
	{
		Scanner input=new Scanner(System.in);
			System.out.println("Nhap họ tên giáo viên:");
			hotengiaovien=input.nextLine();
			System.out.println("Nhap chỉ tiêu:");
			chitieu=Integer.parseInt(input.nextLine());
			System.out.println("Nhap trình độ giáo viên:");
			trinhdo=input.nextLine();
			System.out.println("Nhap chuyên môn giáo viên:");
			chuyenmon=input.nextLine();
			System.out.println("Nhap giới tính giáo viên:");
			gioitinh=input.nextLine();
			System.out.println("Nhap độ tuổi giáo viên:");
			dotuoi=Integer.parseInt(input.nextLine());
	}
	
	public boolean addMenInList(Student x)
	{
	     if (fianceList.size() < q)
	    {
	        fianceList.add(x);
	        //cập nhật những thông tin của ng sinh viên.
	        System.out.println(x.getName()+"gửi lời thực tập đến"+ name);
	        System.out.println(name+ " phân công "+ x.getName());
	        //x.getFianceList().add(this);
	        return true;
	    } 
	    else 
	    {
	    return addMenPreferInList(x);
	    }              
	} 
	public boolean addMenPreferInList(Student y)
	{
	    int min =0;
	    int index_y =0;
	    // tim vi tri cua ng ko duoc uu tien 
	    for(int i=0;i<fianceList.size();i++)
	    {                       
	        for(int j =0;j<preferList.size();j++)
	        {
	        if(fianceList.get(i)==preferList.get(j))
	        if(j> min) min = j;
	        } 
	    }
	    //xác định xem ng sinh viên y trong danh sách nằm ở vị trí nào
	for(int j =0;j<preferList.size();j++)
	{
	    if(y==preferList.get(j))
	    {
	        if(j<min)
	        {
	            //loại ng sinh viên ko được ưu tiên nhất
	            rejectMen(preferList.get(min));
	            //Thêm ng sinh viên y vào danh sách
	            fianceList.add(y);
	            System.out.println(y.getName()+"gửi lời đề nghị đến "+name);   System.out.println(name + "từ chối "+preferList.get(min).getName()+" để nhận lời " + y.getName());
	            System.out.println(preferList.get(min).getName()+" thì độc thân");
	            y.getFianceList().add(this);
	            return true;
	        }
	        else
	        return false;
	        }
	    } 
	    return true;    
	}
	public void rejectMen(Student x)
	 {
	     for(int i=0;i<fianceList.size();i++)
	       if(fianceList.get(i)==x)
	    {
	    fianceList.remove(i);
	    //cập nhật thông tin cho người đàn ông vừa bị loại
	    yeuthich.menList.add(x);
	    }
	} 
}
