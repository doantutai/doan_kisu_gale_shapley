-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Client: 127.0.0.1
-- Généré le: Mar 02 Janvier 2018 à 06:37
-- Version du serveur: 5.6.11
-- Version de PHP: 5.5.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `galeshapley`
--
CREATE DATABASE IF NOT EXISTS `galeshapley` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `galeshapley`;

-- --------------------------------------------------------

--
-- Structure de la table `dieukiengiaovien`
--

CREATE TABLE IF NOT EXISTS `dieukiengiaovien` (
  `idgiaovien` int(11) NOT NULL,
  `tendieukien` varchar(50) CHARACTER SET utf8 NOT NULL,
  `dieukien` varchar(50) CHARACTER SET utf8 NOT NULL,
  `giatridieukien` varchar(50) CHARACTER SET utf8 NOT NULL,
  `iddieukiengv` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`iddieukiengv`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Contenu de la table `dieukiengiaovien`
--

INSERT INTO `dieukiengiaovien` (`idgiaovien`, `tendieukien`, `dieukien`, `giatridieukien`, `iddieukiengv`) VALUES
(1, 'Điểm toán', '>=', '7', 1),
(2, 'Điểm văn', '>', '4', 2),
(3, 'Hạnh kiểm', '=', 'Trung bình', 3),
(4, 'Điểm văn', '>', '4', 4),
(5, 'Trung bình', '>', '6', 5),
(6, 'diemlaptrinhc', '>', '6', 6),
(7, 'diemanh', '>', '5', 7);

-- --------------------------------------------------------

--
-- Structure de la table `dieukiensinhvien`
--

CREATE TABLE IF NOT EXISTS `dieukiensinhvien` (
  `idsinhvien` int(11) NOT NULL,
  `tendieukien` varchar(50) CHARACTER SET utf8 NOT NULL,
  `dieukien` varchar(50) CHARACTER SET utf8 NOT NULL,
  `giatridieukien` varchar(50) CHARACTER SET utf8 NOT NULL,
  `iddieukiensv` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`iddieukiensv`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Contenu de la table `dieukiensinhvien`
--

INSERT INTO `dieukiensinhvien` (`idsinhvien`, `tendieukien`, `dieukien`, `giatridieukien`, `iddieukiensv`) VALUES
(1, 'trình độ', '=', 'thạc sĩ', 1),
(1, 'chuyenmon', '=', 'cntt', 2),
(2, 'dotuoi', '>', '25', 3),
(3, 'gioitinh', '=', 'nam', 4),
(4, 'trinhdo', '=', 'tiến sĩ', 5),
(5, 'dotuoi', '>=', '25', 6),
(6, 'chuyenmon', '=', 'khmt', 7),
(7, 'trinhdo', '=', 'tiến sĩ', 8),
(8, 'dotuoi', '>=', '27', 9),
(9, 'dotuoi', '>', '28', 10);

-- --------------------------------------------------------

--
-- Structure de la table `giaovien`
--

CREATE TABLE IF NOT EXISTS `giaovien` (
  `hotengiaovien` varchar(200) CHARACTER SET utf8 NOT NULL,
  `chitieu` int(11) NOT NULL,
  `idgiaovien` int(11) NOT NULL AUTO_INCREMENT,
  `trinhdo` varchar(200) CHARACTER SET utf8 NOT NULL,
  `chuyenmon` varchar(200) CHARACTER SET utf8 NOT NULL,
  `gioitinh` varchar(10) CHARACTER SET utf8 NOT NULL,
  `dotuoi` int(11) NOT NULL,
  PRIMARY KEY (`idgiaovien`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Contenu de la table `giaovien`
--

INSERT INTO `giaovien` (`hotengiaovien`, `chitieu`, `idgiaovien`, `trinhdo`, `chuyenmon`, `gioitinh`, `dotuoi`) VALUES
('Sơn', 2, 1, 'Tiến sĩ', 'CNTT', 'Nữ', 35),
('vân', 2, 2, 'Thạc sĩ', 'KHMT', 'Nam', 30),
('thanh', 2, 3, 'Giáo sư', 'CNTT', 'Nữ', 25),
('Hoa', 2, 4, 'Thạc sĩ', 'CNTT', 'Nam', 24),
('yi', 2, 5, 'Thạc sĩ', 'CNTT', 'Nam', 28),
('hiệp', 2, 6, 'Tiến sĩ', 'KHMT', 'Nam', 25),
('linh', 2, 7, 'Tiến sĩ', 'KHMT', 'Nữ', 28);

-- --------------------------------------------------------

--
-- Structure de la table `sinhvien`
--

CREATE TABLE IF NOT EXISTS `sinhvien` (
  `idsinhvien` int(11) NOT NULL AUTO_INCREMENT,
  `hotensinhvien` varchar(200) NOT NULL,
  `diemtoan` float NOT NULL,
  `diemvan` float NOT NULL,
  `diemanh` float NOT NULL,
  `diemtrungbinh` float NOT NULL,
  `hanhkiem` varchar(200) NOT NULL,
  PRIMARY KEY (`idsinhvien`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Contenu de la table `sinhvien`
--

INSERT INTO `sinhvien` (`idsinhvien`, `hotensinhvien`, `diemtoan`, `diemvan`, `diemanh`, `diemtrungbinh`, `hanhkiem`) VALUES
(1, 'tài', 8, 6, 7, 7, 'Khá'),
(2, 'vân', 5, 3, 4, 4, 'Tốt'),
(3, 'thanh', 9, 2, 6, 5.66667, 'Trung bình'),
(4, 'liên', 6.5, 7.5, 5.5, 6.5, 'Khá'),
(5, 'dung', 8, 5, 7, 6.66667, 'Tốt'),
(6, 'linh', 3, 7.5, 8, 6.16667, 'Khá'),
(7, 'minh', 5, 5, 7, 5.66667, 'Tốt'),
(8, 'châu', 6.5, 2.5, 8, 5.66667, 'Trung bình'),
(9, 'thanh', 6.5, 3.4, 7.8, 5.9, 'Khá');

-- --------------------------------------------------------

--
-- Structure de la table `topyeuthich`
--

CREATE TABLE IF NOT EXISTS `topyeuthich` (
  `idgiaovien` varchar(200) NOT NULL,
  `idsinhvien` varchar(200) NOT NULL,
  PRIMARY KEY (`idgiaovien`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `topyeuthich`
--

INSERT INTO `topyeuthich` (`idgiaovien`, `idsinhvien`) VALUES
('gv1', 'sv2,sv5'),
('gv2', 'sv3,sv6'),
('gv3', 'sv9'),
('gv4', 'sv1'),
('gv5', 'sv8'),
('gv6', 'sv7,sv4'),
('gv7', '');

-- --------------------------------------------------------

--
-- Structure de la table `yeuthichgiaovien`
--

CREATE TABLE IF NOT EXISTS `yeuthichgiaovien` (
  `idsinhvien` int(11) NOT NULL AUTO_INCREMENT,
  `idgiaovien` varchar(200) NOT NULL,
  PRIMARY KEY (`idsinhvien`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `yeuthichsinhvien`
--

CREATE TABLE IF NOT EXISTS `yeuthichsinhvien` (
  `idgiaovien` int(11) NOT NULL AUTO_INCREMENT,
  `idsinhvien` varchar(200) NOT NULL,
  PRIMARY KEY (`idgiaovien`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
